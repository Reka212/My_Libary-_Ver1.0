import 'package:flutter/material.dart';

class LaporanPage extends StatelessWidget {
  const LaporanPage({super.key});

   @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Laporan"),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            laporanCard("Total Buku", "120"),
            laporanCard("Total Anggota", "80"),
            laporanCard("Total Peminjaman", "25"),
          ],
        ),
      ),
    );
  }

  Widget laporanCard(String title, String total) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.bar_chart, color: Colors.green),
        title: Text(title),
        trailing: Text(
          total,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}