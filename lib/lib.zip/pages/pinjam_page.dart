import 'package:flutter/material.dart';
import '../database/database_helper.dart';

class PinjamPage extends StatefulWidget {
  const PinjamPage({super.key});

  @override
  State<PinjamPage> createState() => _PinjamPageState();
}

class _PinjamPageState extends State<PinjamPage> {
  final TextEditingController idPinjamController = TextEditingController();
  final TextEditingController nomorAnggotaController = TextEditingController();
  final TextEditingController namaAnggotaController = TextEditingController();
  final TextEditingController isbnController = TextEditingController();
  final TextEditingController judulBukuController = TextEditingController();
  final TextEditingController tanggalPinjamController = TextEditingController();
  final TextEditingController tanggalKembaliController =
      TextEditingController();
  final TextEditingController statusController = TextEditingController(
    text: "Dipinjam",
  );
  List<Map<String, dynamic>> pinjamList = [];
  Map<String, dynamic>? selectedAnggota;
  Map<String, dynamic>? selectedBuku;
  List<Map<String, dynamic>> anggotaList = [];
  List<Map<String, dynamic>> bukuList = [];
  @override
  void initState() {
    super.initState();
    loadData();
  }

  void loadData() {
    pinjamList = DatabaseHelper.getAllPinjam();
    anggotaList = DatabaseHelper.getAllAnggota();
    bukuList = DatabaseHelper.getAllBuku();
    setState(() {});
  }

  Future<void> tambahPinjam() async {
    // Cari key buku berdasarkan ISBN
    final keyBuku = DatabaseHelper.getKeyBukuByIsbn(isbnController.text);
    if (keyBuku == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Buku tidak ditemukan.")));
      return;
    }
    final buku = DatabaseHelper.getAllBuku()[keyBuku];
    final stok = (buku['stok'] ?? 0) as int;
    if (stok <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Buku sudah habis dipinjam."),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }
    await DatabaseHelper.kurangiStokBuku(keyBuku);
    await DatabaseHelper.tambahPinjam(
      idPinjam: idPinjamController.text,
      nomorAnggota: nomorAnggotaController.text,
      namaAnggota: namaAnggotaController.text,
      isbn: isbnController.text,
      judulBuku: judulBukuController.text,
      tanggalPinjam: tanggalPinjamController.text,
      tanggalKembali: tanggalKembaliController.text,
      status: statusController.text,
    );
    loadData();
    Navigator.pop(context);
  }

  void showTambahDialog() {
    idPinjamController.clear();
    nomorAnggotaController.clear();
    namaAnggotaController.clear();
    isbnController.clear();
    judulBukuController.clear();
    tanggalPinjamController.clear();
    tanggalKembaliController.clear();
    statusController.text = "Dipinjam";
    selectedAnggota = null;
    selectedBuku = null;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Peminjaman Buku"),
        content: SingleChildScrollView(
          child: SizedBox(
            width: 500,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: idPinjamController,
                  decoration: const InputDecoration(
                    labelText: "ID Peminjaman",
                    border: OutlineInputBorder(),
                  ),
                ),

                const SizedBox(height: 10),

                DropdownButtonFormField<Map<String, dynamic>>(
                  value: selectedAnggota,
                  decoration: const InputDecoration(
                    labelText: "Pilih Anggota",
                    border: OutlineInputBorder(),
                  ),
                  items: anggotaList.map((anggota) {
                    return DropdownMenuItem(
                      value: anggota,
                      child: Text(anggota['nama']),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        selectedAnggota = value;
                        nomorAnggotaController.text = value['nomorAnggota'];
                        namaAnggotaController.text = value['nama'];
                      });
                    }
                  },
                ),

                const SizedBox(height: 10),

                Card(
                  color: Colors.green.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.person, color: Colors.green),
                    title: Text(
                      namaAnggotaController.text.isEmpty
                          ? "-"
                          : namaAnggotaController.text,
                    ),
                    subtitle: Text(
                      "No Anggota : ${nomorAnggotaController.text.isEmpty ? "-" : nomorAnggotaController.text}",
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                DropdownButtonFormField<Map<String, dynamic>>(
                  value: selectedBuku,
                  decoration: const InputDecoration(
                    labelText: "Pilih Buku",
                    border: OutlineInputBorder(),
                  ),
                  items: bukuList.map((buku) {
                    final stok = buku['stok'] ?? 0;

                    return DropdownMenuItem(
                      value: buku,
                      enabled: stok > 0,
                      child: Text(
                        stok > 0
                            ? "${buku['judul']} (Stok: $stok)"
                            : "${buku['judul']} (HABIS)",
                      ),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        selectedBuku = value;
                        isbnController.text = value['isbn'];
                        judulBukuController.text = value['judul'];
                      });
                    }
                  },
                ),

                const SizedBox(height: 10),

                Card(
                  color: Colors.blue.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.book, color: Colors.blue),
                    title: Text(
                      judulBukuController.text.isEmpty
                          ? "-"
                          : judulBukuController.text,
                    ),
                    subtitle: Text(
                      "ISBN : ${isbnController.text.isEmpty ? "-" : isbnController.text}",
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                TextField(
                  controller: tanggalPinjamController,
                  readOnly: true,
                  decoration: const InputDecoration(
                    labelText: "Tanggal Pinjam",
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  onTap: () {
                    pilihTanggal(tanggalPinjamController);
                  },
                ),

                const SizedBox(height: 10),

                TextField(
                  controller: tanggalKembaliController,
                  readOnly: true,
                  decoration: const InputDecoration(
                    labelText: "Tanggal Kembali",
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  onTap: () {
                    pilihTanggal(tanggalKembaliController);
                  },
                ),

                const SizedBox(height: 10),

                DropdownButtonFormField<String>(
                  value: statusController.text,
                  decoration: const InputDecoration(
                    labelText: "Status",
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: "Dipinjam",
                      child: Text("Dipinjam"),
                    ),
                    DropdownMenuItem(value: "Kembali", child: Text("Kembali")),
                  ],
                  onChanged: (value) {
                    statusController.text = value!;
                  },
                ),
              ],
            ),
          ),
        ),

        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text("Batal"),
          ),

          ElevatedButton(onPressed: tambahPinjam, child: const Text("Simpan")),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Peminjaman Buku"),
        centerTitle: true,
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: pinjamList.isEmpty
          ? const Center(
              child: Text(
                "Belum ada data peminjaman",
                style: TextStyle(fontSize: 16),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: pinjamList.length,
              itemBuilder: (context, index) {
                final pinjam = pinjamList[index];

                return Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  margin: const EdgeInsets.only(bottom: 15),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        /// Judul Buku
                        Row(
                          children: [
                            const Icon(
                              Icons.menu_book,
                              color: Colors.green,
                              size: 30,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                pinjam['judulBuku'],
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 15),

                        const Divider(),

                        Row(
                          children: [
                            const Icon(
                              Icons.confirmation_number,
                              color: Colors.blue,
                            ),
                            const SizedBox(width: 10),
                            Text("ID Pinjam : ${pinjam['idPinjam']}"),
                          ],
                        ),

                        const SizedBox(height: 8),

                        Row(
                          children: [
                            const Icon(Icons.person, color: Colors.orange),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text("Nama : ${pinjam['namaAnggota']}"),
                            ),
                          ],
                        ),

                        const SizedBox(height: 8),

                        Row(
                          children: [
                            const Icon(Icons.badge, color: Colors.purple),
                            const SizedBox(width: 10),
                            Text("No Anggota : ${pinjam['nomorAnggota']}"),
                          ],
                        ),

                        const SizedBox(height: 8),

                        Row(
                          children: [
                            const Icon(Icons.qr_code, color: Colors.teal),
                            const SizedBox(width: 10),
                            Expanded(child: Text("ISBN : ${pinjam['isbn']}")),
                          ],
                        ),

                        const SizedBox(height: 8),

                        Row(
                          children: [
                            const Icon(
                              Icons.calendar_today,
                              color: Colors.green,
                            ),
                            const SizedBox(width: 10),
                            Text("Pinjam : ${pinjam['tanggalPinjam']}"),
                          ],
                        ),

                        const SizedBox(height: 8),

                        Row(
                          children: [
                            const Icon(
                              Icons.event_available,
                              color: Colors.red,
                            ),
                            const SizedBox(width: 10),
                            Text("Kembali : ${pinjam['tanggalKembali']}"),
                          ],
                        ),

                        const SizedBox(height: 15),

                        Align(
                          alignment: Alignment.centerLeft,
                          child: Chip(
                            avatar: Icon(
                              pinjam['status'] == "Dipinjam"
                                  ? Icons.book
                                  : Icons.check_circle,
                              color: Colors.white,
                              size: 18,
                            ),
                            label: Text(
                              pinjam['status'],
                              style: const TextStyle(color: Colors.white),
                            ),
                            backgroundColor: pinjam['status'] == "Dipinjam"
                                ? Colors.orange
                                : Colors.green,
                          ),
                        ),

                        const Divider(height: 25),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orange,
                                foregroundColor: Colors.white,
                              ),
                              onPressed: () {
                                editPinjam(pinjam);
                              },
                              icon: const Icon(Icons.edit),
                              label: const Text("Edit"),
                            ),

                            const SizedBox(width: 10),

                            ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                                foregroundColor: Colors.white,
                              ),
                              onPressed: () {
                                hapusPinjam(pinjam['key']);
                              },
                              icon: const Icon(Icons.delete),
                              label: const Text("Hapus"),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        onPressed: showTambahDialog,
        child: const Icon(Icons.add),
      ),
    );
  }

  @override
  void dispose() {
    idPinjamController.dispose();
    nomorAnggotaController.dispose();
    namaAnggotaController.dispose();
    isbnController.dispose();
    judulBukuController.dispose();
    tanggalPinjamController.dispose();
    tanggalKembaliController.dispose();
    statusController.dispose();
    super.dispose();
  }

  Future<void> pilihTanggal(TextEditingController controller) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      controller.text =
          "${picked.day.toString().padLeft(2, '0')}-"
          "${picked.month.toString().padLeft(2, '0')}-"
          "${picked.year}";
    }
  }

  Future<void> hapusPinjam(int key) async {
    final konfirmasi = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Hapus Peminjaman"),
        content: const Text(
          "Apakah Anda yakin ingin menghapus data peminjaman ini?",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Batal"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Hapus"),
          ),
        ],
      ),
    );

    if (konfirmasi == true) {
      await DatabaseHelper.deletePinjam(key);
      loadData();
    }
  }

  void editPinjam(Map<String, dynamic> pinjam) {
    // Isi controller dengan data lama
    idPinjamController.text = pinjam['idPinjam'] ?? '';
    nomorAnggotaController.text = pinjam['nomorAnggota'] ?? '';
    namaAnggotaController.text = pinjam['namaAnggota'] ?? '';
    isbnController.text = pinjam['isbn'] ?? '';
    judulBukuController.text = pinjam['judulBuku'] ?? '';
    tanggalPinjamController.text = pinjam['tanggalPinjam'] ?? '';
    tanggalKembaliController.text = pinjam['tanggalKembali'] ?? '';
    statusController.text = pinjam['status'] ?? 'Dipinjam';

    // Cari anggota yang sesuai
    selectedAnggota = null;

    for (var anggota in anggotaList) {
      if (anggota['nomorAnggota'].toString() ==
          pinjam['nomorAnggota'].toString()) {
        selectedAnggota = anggota;
        break;
      }
    }

    // Cari buku yang sesuai
    selectedBuku = null;

    for (var buku in bukuList) {
      if (buku['isbn'].toString() == pinjam['isbn'].toString()) {
        selectedBuku = buku;
        break;
      }
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Edit Peminjaman Buku"),
        content: SingleChildScrollView(
          child: SizedBox(
            width: 500,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: idPinjamController,
                  decoration: const InputDecoration(
                    labelText: "ID Peminjaman",
                    border: OutlineInputBorder(),
                  ),
                ),

                const SizedBox(height: 10),

                DropdownButtonFormField<Map<String, dynamic>>(
                  initialValue: selectedAnggota,
                  decoration: const InputDecoration(
                    labelText: "Pilih Anggota",
                    border: OutlineInputBorder(),
                  ),
                  items: anggotaList.map((anggota) {
                    return DropdownMenuItem(
                      value: anggota,
                      child: Text(anggota['nama']),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        selectedAnggota = value;
                        nomorAnggotaController.text = value['nomorAnggota'];
                        namaAnggotaController.text = value['nama'];
                      });
                    }
                  },
                ),

                const SizedBox(height: 10),

                Card(
                  color: Colors.green.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.person, color: Colors.green),
                    title: Text(
                      namaAnggotaController.text.isEmpty
                          ? "-"
                          : namaAnggotaController.text,
                    ),
                    subtitle: Text(
                      "No Anggota : ${nomorAnggotaController.text.isEmpty ? "-" : nomorAnggotaController.text}",
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                DropdownButtonFormField<Map<String, dynamic>>(
                  initialValue: selectedBuku,
                  decoration: const InputDecoration(
                    labelText: "Pilih Buku",
                    border: OutlineInputBorder(),
                  ),
                  items: bukuList.map((buku) {
                    return DropdownMenuItem(
                      value: buku,
                      child: Text(buku['judul']),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        selectedBuku = value;
                        isbnController.text = value['isbn'];
                        judulBukuController.text = value['judul'];
                      });
                    }
                  },
                ),

                const SizedBox(height: 10),

                Card(
                  color: Colors.blue.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.book, color: Colors.blue),
                    title: Text(
                      judulBukuController.text.isEmpty
                          ? "-"
                          : judulBukuController.text,
                    ),
                    subtitle: Text(
                      "ISBN : ${isbnController.text.isEmpty ? "-" : isbnController.text}",
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                TextField(
                  controller: tanggalPinjamController,
                  readOnly: true,
                  decoration: const InputDecoration(
                    labelText: "Tanggal Pinjam",
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  onTap: () {
                    pilihTanggal(tanggalPinjamController);
                  },
                ),

                const SizedBox(height: 10),

                TextField(
                  controller: tanggalKembaliController,
                  readOnly: true,
                  decoration: const InputDecoration(
                    labelText: "Tanggal Kembali",
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  onTap: () {
                    pilihTanggal(tanggalKembaliController);
                  },
                ),

                const SizedBox(height: 10),

                DropdownButtonFormField<String>(
                  value: statusController.text,
                  decoration: const InputDecoration(
                    labelText: "Status",
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: "Dipinjam",
                      child: Text("Dipinjam"),
                    ),
                    DropdownMenuItem(value: "Kembali", child: Text("Kembali")),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      statusController.text = value;
                    }
                  },
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text("Batal"),
          ),
          ElevatedButton(
            onPressed: () async {
              await DatabaseHelper.updatePinjam(
                key: pinjam['key'],
                idPinjam: idPinjamController.text,
                nomorAnggota: nomorAnggotaController.text,
                namaAnggota: namaAnggotaController.text,
                isbn: isbnController.text,
                judulBuku: judulBukuController.text,
                tanggalPinjam: tanggalPinjamController.text,
                tanggalKembali: tanggalKembaliController.text,
                status: statusController.text,
              );

              loadData();

              Navigator.pop(context);
            },
            child: const Text("Update"),
          ),
        ],
      ),
    );
  }
}
