import 'package:flutter/material.dart';
import '../components/ui_components.dart';
class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override
  State<RegisterPage> createState() => _RegisterPageState();
}
class _RegisterPageState extends State<RegisterPage> {
  final username = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final password = TextEditingController();
  final confirmPassword = TextEditingController();
  bool hidePass = true;
  bool hideConfirm = true;
  void handleRegister() {
    if (username.text.isEmpty ||
        email.text.isEmpty ||
        phone.text.isEmpty ||
        password.text.isEmpty ||
        confirmPassword.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Semua field wajib diisi!")),
      );
      return;
    }
    if (password.text != confirmPassword.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Password tidak sama!")),
      );
      return;
    }
   ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Register berhasil (dummy)!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      body: SingleChildScrollView(
        child: Column(
          children: [
            UIComponents.header("Register"),
            const SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // Username
                  UIComponents.inputField(
                    controller: username,
                    label: "Username",
                    icon: Icons.person,
                  ),
                 const SizedBox(height: 15),
                  UIComponents.inputField(
                    controller: email,
                    label: "Email",
                    icon: Icons.email,
                  ),
                  const SizedBox(height: 15),
                  UIComponents.inputField(
                    controller: phone,
                    label: "No HP",
                    icon: Icons.phone,
                  ),
                  const SizedBox(height: 15),
                  UIComponents.inputField(
                    controller: password,
                    label: "Password",
                    icon: Icons.lock,
                    isPassword: true,
                    obscureText: hidePass,
                    togglePassword: () {
                      setState(() {
                        hidePass = !hidePass;
                      });
                    }, ),
                  const SizedBox(height: 15),
                  UIComponents.inputField(
                    controller: confirmPassword,
                    label: "Konfirmasi Password",
                    icon: Icons.lock_outline,
                    isPassword: true,
                    obscureText: hideConfirm,
                    togglePassword: () {
                      setState(() {
                        hideConfirm = !hideConfirm;
                      });
                    },),
                  const SizedBox(height: 25),
                  UIComponents.primaryButton(
                    text: "Register",
                    onPressed: handleRegister,
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Sudah punya akun? "),
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: const Text(
                          "Login",
                          style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                          ), ), ),
                    ], ), ], ),
            ),],),),);}}
